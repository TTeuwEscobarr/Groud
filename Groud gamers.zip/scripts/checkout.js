const checkoutElement = document.querySelector('#checkout');

function collectCheckoutFields() {
  const container = document.getElementById('checkout_fields');
  const result = {};

  if (!container) return result;

  container.querySelectorAll('[data-field-id]').forEach((element) => {
    const fieldId = element.getAttribute('data-field-id');
    const fieldType = element.getAttribute('data-field-type');
    if (!fieldId) return;

    if (fieldType === 'SELECT') {
      const select = element.querySelector('select');
      if (select && select.value) result[fieldId] = select.value;
    } else if (fieldType === 'ROBLOX') {
      const value = element.getAttribute('data-value') || '';
      if (value) result[fieldId] = value;
    } else {
      const input = element.querySelector('input');
      const value = (input?.value || '').trim();
      if (value) result[fieldId] = value;
    }
  });

  return result;
}

CentralCart.PixCheckout.init({
  getSelectedButton: () =>
    checkoutElement.querySelector('[data-payment-method][data-selected="true"]'),
});

document.addEventListener('pix:requirements-changed', (event) => {
  const { requireDocument, requirePhone, requireAddress } = event.detail || {};

  const docField = checkoutElement.querySelector('input[name="client_document"]');
  if (docField) {
    const storeRequiresDoc = docField.getAttribute('data-required') === 'true';
    if (requireDocument || storeRequiresDoc) docField.classList.remove('hidden');
    else docField.classList.add('hidden');
  }

  const addressSection = checkoutElement.querySelector('#address-section');
  if (addressSection) {
    const storeRequiresAddress = addressSection.getAttribute('data-require-address') === 'true';
    const cepInput = addressSection.querySelector('input[name="address_cep"]');
    const numberInput = addressSection.querySelector('input[name="address_number"]');

    if (requireAddress || storeRequiresAddress) {
      addressSection.classList.remove('hidden');
      addressSection.classList.add('block');
      if (requireAddress) {
        cepInput?.setAttribute('required', 'true');
        numberInput?.setAttribute('required', 'true');
      }
    } else {
      addressSection.classList.add('hidden');
      addressSection.classList.remove('block');
      cepInput?.removeAttribute('required');
      numberInput?.removeAttribute('required');
    }
  }

  const phoneWrapper = checkoutElement.querySelector('#phone-field-wrapper');
  if (phoneWrapper) {
    const phoneMode = phoneWrapper.getAttribute('data-phone-mode') || 'DISABLED';
    const showPhone = requirePhone || phoneMode === 'OPTIONAL' || phoneMode === 'REQUIRED';
    if (showPhone) {
      phoneWrapper.classList.remove('hidden');
      PhoneInput.init(phoneWrapper);
      const phoneInput = phoneWrapper.querySelector('input[name="client_phone"]');
      if (phoneInput) {
        phoneInput.placeholder =
          phoneMode === 'OPTIONAL' && !requirePhone ? 'Telefone (opcional)' : 'Telefone';
      }
    } else {
      phoneWrapper.classList.add('hidden');
    }
  }
});

(function handleSelectPaymentMethod() {
  const buttons = checkoutElement.querySelectorAll('[data-payment-method]');
  const creditCardForm = document.getElementById('creditcard-form');

  buttons.forEach((element) => {
    const paymentMethod = element.getAttribute('data-payment-method');

    element.addEventListener('click', () => {
      if (element.getAttribute('data-selected') === 'true') return;

      checkoutElement
        .querySelectorAll('[data-payment-method][data-selected="true"]')
        .forEach((el) => el.setAttribute('data-selected', 'false'));

      element.setAttribute('data-selected', 'true');
      window.selectedGateway = paymentMethod;

      try {
        localStorage.setItem('checkout-gateway', paymentMethod);
      } catch {}

      const rawFee = element.getAttribute('data-fee');
      const feeValue = rawFee && rawFee !== 'null' && rawFee !== '' ? parseFloat(rawFee) : 0;
      const isPercentageFee = element.getAttribute('data-is-percentage-fee') === 'true';

      window.selectedGatewayData = {
        provider: element.getAttribute('data-provider') || null,
        payeeCode: element.getAttribute('data-payee-code') || null,
        maxInstallments: parseInt(element.getAttribute('data-max-installments') || '12', 10),
        fee: feeValue,
        isPercentageFee: isPercentageFee,
      };

      document.dispatchEvent(new CustomEvent('gateway:changed'));

      const docField = checkoutElement.querySelector('input[name="client_document"]');
      if (docField) IMask(docField, { mask: '000.000.000-00' });

      if (creditCardForm) {
        if (paymentMethod === 'CREDITCARD') {
          creditCardForm.classList.remove('hidden');
          CreditCardHandler.init(checkoutElement, {
            onBrandChange: (brand) => {
              const iconEl = document.getElementById('card-brand-icon');
              if (!iconEl) return;

              if (!brand) {
                iconEl.innerHTML = '';
                return;
              }

              iconEl.innerHTML = `<img src="https://cdn.centralcart.io/public/gateway-icons/${brand.toLowerCase()}.svg" alt="${brand}" class="size-6" onerror="this.style.display='none'" onload="this.style.display=''" />`;
            },
          });
        } else {
          creditCardForm.classList.add('hidden');
        }
      }
    });

  });

  let savedGateway = null;
  try {
    savedGateway = localStorage.getItem('checkout-gateway');
  } catch {}

  const savedButton = savedGateway
    ? checkoutElement.querySelector(`[data-payment-method="${savedGateway}"]`)
    : null;

  (savedButton || buttons[0])?.click();
})();

window.Checkout = Object.assign(window.Checkout || {}, {
  getSelectedGateway() {
    return window.selectedGateway || null;
  },
});

(function initAddressAutofill() {
  const addressSection = document.getElementById('address-section');
  if (!addressSection) return;

  const cepInput = addressSection.querySelector('input[name="address_cep"]');
  const streetInput = addressSection.querySelector('input[name="address_street"]');
  const neighborhoodInput = addressSection.querySelector('input[name="address_neighborhood"]');
  const cityInput = addressSection.querySelector('input[name="address_city"]');
  const stateInput = addressSection.querySelector('input[name="address_state"]');
  const cepLoading = document.getElementById('cep-loading');
  const cepError = document.getElementById('cep-error');

  if (!cepInput) return;

  let debounceTimer;

  cepInput.addEventListener('input', (e) => {
    cepInput.value = CentralCart.formatCEP(cepInput.value);
    if (cepError) cepError.textContent = '';

    const clean = cepInput.value.replace(/\D/g, '');
    clearTimeout(debounceTimer);

    if (clean.length === 8) {
      debounceTimer = setTimeout(() => fetchCep(clean), 300);
    }
  });

  async function fetchCep(cep) {
    try {
      if (cepLoading) cepLoading.classList.remove('hidden');
      if (cepError) cepError.textContent = '';

      const data = await CentralCart.fetchCEP(cep);

      if (streetInput && data.logradouro) streetInput.value = data.logradouro;
      if (neighborhoodInput && data.bairro) neighborhoodInput.value = data.bairro;
      if (cityInput && data.localidade) cityInput.value = data.localidade;
      if (stateInput && data.uf) stateInput.value = data.uf;

      const numberInput = addressSection.querySelector('input[name="address_number"]');
      if (numberInput) numberInput.focus();
    } catch (err) {
      if (cepError) cepError.textContent = err.message || 'CEP não encontrado.';
    } finally {
      if (cepLoading) cepLoading.classList.add('hidden');
    }
  }
})();

(function initCheckoutRendering() {
  if (!checkoutElement) return;

  const packagesList = checkoutElement.querySelector('#packages-list');
  const emptyPackagesHTML = checkoutElement.querySelector('#empty-packages')?.outerHTML || '';
  const upsellContainer = checkoutElement.querySelector('#upsell-recommendations');
  const pricing = checkoutElement.querySelector('#pricing');
  const coupon = checkoutElement.querySelector('#coupon');
  const couponInput = coupon?.querySelector('input');
  const couponButton = coupon?.querySelector('button');
  const couponError = coupon?.querySelector('#coupon-error');

  let appliedDiscount = null;

  function setCouponButtonState(state) {
    if (!couponButton) return;
    couponButton.setAttribute('data-state', state);
  }

  const promoRules = getScriptData('__centralcart_promos', []);

  const expandedProgress = new Set();

  function computePromos() {
    const empty = {
      discount: 0,
      name: '',
      offers: [],
      progress: [],
      byPackage: {},
      badges: {},
    };

    if (!promoRules.length) return empty;
    if (typeof CentralCart.calculatePromos !== 'function') return empty;

    return CentralCart.calculatePromos({
      rules: promoRules,
      items: window.Cart?.getPackages?.() || [],
      currency: store.currency,
    });
  }

  window.__ccRewardDiscount = (packageId) =>
    computePromos().byPackage[packageId] || 0;

  window.__ccRewardBadge = (packageId) => computePromos().badges[packageId] || '';

  function tierRewardLabel(tier) {
    if (tier.reward_type === 'FREE') return 'um brinde';

    if (tier.reward_type === 'PERCENTAGE') {
      return `${Number(tier.reward_value || 0)}% de desconto`;
    }

    return `${CentralCart.formatPrice(Number(tier.reward_value || 0), store.currency)} de desconto`;
  }

  function amountLabel(rule, amount) {
    if (rule.condition_mode === 'QUANTITY') {
      const rounded = Math.ceil(amount);

      return `${rounded} ${rounded === 1 ? 'item' : 'itens'}`;
    }

    return CentralCart.formatPrice(amount, store.currency);
  }

  function renderPromoProgress(list) {
    const container = document.getElementById('promo-progress');
    if (!container) return;

    if (!list || !list.length) {
      container.innerHTML = '';
      return;
    }

    container.innerHTML = getPromoProgressRender(
      list.map((entry) => {
        const tiers = [...entry.rule.tiers].sort(
          (a, b) => Number(a.min_amount) - Number(b.min_amount),
        );

        const reachedIndex = tiers.findIndex(
          (tier) =>
            entry.reached && Number(tier.min_amount) === Number(entry.reached.min_amount),
        );

        const target = entry.next
          ? Number(entry.next.min_amount)
          : Number(entry.reached.min_amount);

        return {
          id: entry.rule.id,
          name: entry.rule.name,
          reached: !!entry.reached,
          level: `Nível ${reachedIndex + 1}`,
          current: entry.next
            ? {
                done: false,
                label: tierRewardLabel(entry.next),
                missing: amountLabel(
                  entry.rule,
                  Number(entry.next.min_amount) - entry.current,
                ),
              }
            : { done: true, label: tierRewardLabel(entry.reached) },
          progress: `${amountLabel(entry.rule, entry.current)} / ${amountLabel(entry.rule, target)}`,
          percent: target > 0 ? Math.min(100, (entry.current / target) * 100) : 100,
          collapsed: !expandedProgress.has(entry.rule.id),
          completed: !entry.next,
          levels: tiers.slice(0, reachedIndex + 2).map((tier, index) => ({
            number: index + 1,
            label: tierRewardLabel(tier),
            done: index <= reachedIndex,
            missing: amountLabel(entry.rule, Number(tier.min_amount) - entry.current),
          })),
        };
      }),
    );

    container.querySelectorAll('[data-progress-toggle]').forEach((button) => {
      button.addEventListener('click', () => {
        const id = Number(button.getAttribute('data-progress-toggle'));

        if (expandedProgress.has(id)) expandedProgress.delete(id);
        else expandedProgress.add(id);

        renderPromoProgress(computePromos().progress);
      });
    });

    try {
      window.lucide?.createIcons?.();
    } catch (err) {}
  }

  function rewardProductView(tier, product) {
    const price = Number(product.price || 0);
    const discount =
      tier.reward_type === 'FREE'
        ? price
        : tier.reward_type === 'PERCENTAGE'
          ? price * (Number(tier.reward_value || 0) / 100)
          : Math.min(Number(tier.reward_value || 0), price);
    const final = Math.max(0, price - discount);

    return {
      id: product.id,
      name: product.name,
      image: product.image,
      quantity: Math.max(1, Number(tier.reward_quantity || 1)),
      original: CentralCart.formatPrice(price, store.currency),
      final: CentralCart.formatPrice(final, store.currency),
      badge:
        tier.reward_type === 'PERCENTAGE'
          ? `-${Number(tier.reward_value || 0)}% OFF`
          : `-${CentralCart.formatPrice(discount, store.currency)}`,
      discounted: discount > 0,
      free: final <= 0,
    };
  }

  function renderPromoOffers(offers) {
    const container = document.getElementById('promo-offer');
    if (!container) return;

    if (!offers || !offers.length) {
      container.innerHTML = '';
      return;
    }

    container.innerHTML = getPromoOffersRender(
      offers.map((offer) => ({
        name: offer.rule.name,
        products: offer.products.map((product) => rewardProductView(offer.tier, product)),
      })),
    );

    try {
      window.lucide?.createIcons?.();
    } catch (err) {}

    container.querySelectorAll('[data-reward-add]').forEach((button) => {
      button.addEventListener('click', async () => {
        const id = parseInt(button.getAttribute('data-reward-add'));
        const quantity = parseInt(button.getAttribute('data-reward-quantity')) || 1;

        const refresh = async () => {
          await window.Cart?.calculate?.();
          renderPackages();
        };

        const existing = (window.Cart?.get?.() || []).find(
          (item) => parseInt(item.id) === id,
        );

        if (existing) {
          window.Cart?.update?.(id, parseInt(existing.quantity || 1) + quantity);
          await refresh();
          return;
        }

        CustomFields.addToCart({
          id,
          quantity,
          fields: [],
          opts: {},
          onAdded: refresh,
        });
      });
    });
  }
  function computeTotals() {
    const subtotal = window.Cart?.calculateTotal?.() || 0;

    let couponDiscount = 0;
    if (appliedDiscount && subtotal > 0) {
      const applicableSubtotal = subtotal;

      if (appliedDiscount.type === 'PERCENTAGE') {
        couponDiscount = applicableSubtotal * (Number(appliedDiscount.value || 0) / 100);
      } else if (appliedDiscount.type === 'PRICE') {
        couponDiscount = Math.min(Number(appliedDiscount.value || 0), applicableSubtotal);
      }
    }

    let gatewayDiscount = 0;
    let feeValue = 0;
    const gatewayData = window.selectedGatewayData;
    if (gatewayData && gatewayData.fee !== 0 && subtotal > 0) {
      if (gatewayData.fee < 0) {
        const absFee = Math.abs(gatewayData.fee);
        if (gatewayData.isPercentageFee) {
          gatewayDiscount = subtotal * (absFee / 100);
        } else {
          gatewayDiscount = absFee;
        }
      } else {
        const afterDiscount = Math.max(0, subtotal - couponDiscount);
        if (gatewayData.isPercentageFee) {
          feeValue = afterDiscount * (gatewayData.fee / 100);
        } else {
          feeValue = gatewayData.fee;
        }
      }
    }

    const promos = computePromos();

    const totalDiscount = couponDiscount + gatewayDiscount + promos.discount;
    const total = Math.max(0, subtotal - totalDiscount + feeValue);

    const creditApplied = computeCreditApplied(total);

    return {
      subtotal,
      discountValue: totalDiscount,
      promos,
      feeValue,
      creditApplied,
      totalBeforeCredit: total,
      total: Math.max(0, total - creditApplied),
    };
  }

  const creditBlock = document.getElementById('credit-block');
  const creditCheckbox = document.getElementById('use-credit');
  const creditDivider = document.getElementById('credit-divider');
  const creditStateEls = ['credit-block', 'credit-icon', 'credit-indicator'];

  function creditRules() {
    if (!creditBlock || typeof CentralCart.calculateCredit !== 'function') return null;

    return {
      balance: Number(creditBlock.getAttribute('data-balance') || 0),
      maxPercent: Number(creditBlock.getAttribute('data-max-percent') || 0),
      minSpend: Number(creditBlock.getAttribute('data-min-spend') || 0),
    };
  }

  function computeCreditApplied(total, ignoreCheckbox = false) {
    const rules = creditRules();

    if (!rules || (!ignoreCheckbox && !creditCheckbox?.checked)) return 0;

    return CentralCart.calculateCredit({
      total,
      balance: rules.balance,
      maxPercent: rules.maxPercent,
      minSpend: rules.minSpend,
    });
  }

  function paintCreditState(active) {
    creditStateEls.forEach((id) => {
      document.getElementById(id)?.setAttribute('data-active', String(active));
    });
  }

  function updateCreditUI(creditApplied, totalBeforeCredit) {
    const rules = creditRules();

    if (!creditBlock) return;

    if (!rules) {
      creditBlock.classList.add('hidden');
      creditBlock.classList.remove('flex');
      creditDivider?.classList.add('hidden');
      return;
    }

    const eligible = rules.balance > 0 && totalBeforeCredit >= Math.max(rules.minSpend, 0.01);

    creditBlock.classList.toggle('hidden', !eligible);
    creditBlock.classList.toggle('flex', eligible);
    creditDivider?.classList.toggle('hidden', !eligible);

    if (!eligible) {
      if (creditCheckbox?.checked) {
        creditCheckbox.checked = false;
        paintCreditState(false);
      }
      return;
    }

    paintCreditState(!!creditCheckbox?.checked);

    const hint = document.getElementById('credit-hint');
    if (!hint) return;

    const amount = creditApplied > 0 ? creditApplied : computeCreditApplied(totalBeforeCredit, true);

    hint.textContent = creditCheckbox?.checked
      ? `${CentralCart.formatPrice(amount, store.currency)} aplicados neste pedido`
      : `Aplicar ${CentralCart.formatPrice(amount, store.currency)} neste pedido`;
  }

  creditCheckbox?.addEventListener('change', () => updatePricingUI());

  function updatePricingUI() {
    if (!pricing) return;
    const {
      subtotal,
      discountValue,
      promos,
      feeValue,
      creditApplied,
      totalBeforeCredit,
      total,
    } = computeTotals();
    const subtotalEl = pricing.querySelector('.subtotal-value');
    const discountEl = pricing.querySelector('.discount-value');
    const feeEl = pricing.querySelector('.fee-value');
    const feeRow = document.getElementById('fee-row');
    const totalEl = pricing.querySelector('.total-value');
    const payButtonPrice = document.querySelector('#pay-button-price');

    if (subtotalEl) subtotalEl.textContent = CentralCart.formatPrice(subtotal, store.currency);
    if (discountEl) discountEl.textContent = CentralCart.formatPrice(discountValue, store.currency);
    if (feeRow) {
      if (feeValue > 0) {
        feeRow.classList.remove('hidden');
        if (feeEl) feeEl.textContent = CentralCart.formatPrice(feeValue, store.currency);
      } else {
        feeRow.classList.add('hidden');
      }
    }
    renderPromoOffers(promos.offers);
    renderPromoProgress(promos.progress);

    const creditRow = document.getElementById('credit-row');
    if (creditRow) {
      const creditEl = pricing.querySelector('.credit-value');
      if (creditApplied > 0) {
        creditRow.classList.remove('hidden');
        if (creditEl)
          creditEl.textContent = `- ${CentralCart.formatPrice(creditApplied, store.currency)}`;
      } else {
        creditRow.classList.add('hidden');
      }
    }

    updateCreditUI(creditApplied, totalBeforeCredit);

    if (totalEl) totalEl.textContent = CentralCart.formatPrice(total, store.currency);
    if (payButtonPrice) payButtonPrice.textContent = CentralCart.formatPrice(total, store.currency);

    document.dispatchEvent(
      new CustomEvent('checkout:totals-updated', {
        detail: { subtotal, total, feeValue, discountValue },
      }),
    );
  }

  function isUpsellAddon(type) {
    return type !== 'ALTERNATIVE' && type !== 'POST_SALE';
  }

  let alternativesByTrigger = new Map();

  let lastUpsellCartKey = null;
  let cachedUpsells = null;
  const upsellOrder = new Map();
  let upsellOrderSeq = 0;
  const upsellFieldsById = new Map();

  function bindUpsellAdds(container) {
    container.querySelectorAll('[data-upsell-add]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const id = parseInt(btn.getAttribute('data-upsell-add'));
        const rawTrigger = btn.getAttribute('data-upsell-trigger');
        const triggerId = rawTrigger ? parseInt(rawTrigger) : null;
        const type = btn.getAttribute('data-upsell-type');

        CustomFields.addToCart({
          id,
          fields: upsellFieldsById.get(id) || [],
          opts: { is_upsell: true, upsell_trigger_id: triggerId, upsell_type: type },
          onAdded: async () => {
            if (type === 'ALTERNATIVE' && triggerId) Cart.remove(triggerId);
            await window.Cart?.calculate?.();
            renderPackages();
            renderUpsells();
          },
        });
      });
    });
  }

  function renderPackages() {
    if (!packagesList) return;
    const pkgs = (window.Cart?.getPackages?.() || []).filter(
      (p) => !(p.cart_item && p.cart_item.is_upsell && isUpsellAddon(p.cart_item.upsell_type)),
    );
    if (!pkgs.length) {
      packagesList.innerHTML = emptyPackagesHTML;
      updatePricingUI();
      return;
    }

    packagesList.innerHTML = pkgs
      .map((pkg) => {
        const item = getCheckoutItemsRender([pkg]);
        const alts = alternativesByTrigger.get(pkg.id) || [];
        if (!alts.length) return item;
        return `<div class="space-y-2">${item}${getUpsellAlternativesRender(alts)}</div>`;
      })
      .join('');

    try {
      window.lucide?.createIcons?.();
    } catch {}
    updatePricingUI();
    initCartActionListeners(packagesList);
    bindUpsellAdds(packagesList);
  }

  async function renderUpsells() {
    if (!upsellContainer) return;

    const cartIds = (Cart.get() || []).map((i) => parseInt(i.id));
    if (!cartIds.length) {
      upsellContainer.innerHTML = '';
      alternativesByTrigger = new Map();
      lastUpsellCartKey = null;
      cachedUpsells = null;
      renderPackages();
      return;
    }

    const cartKey = [...new Set(cartIds)].sort((a, b) => a - b).join(',');
    if (cachedUpsells && cartKey === lastUpsellCartKey) {
      renderUpsellsFrom(cachedUpsells);
      return;
    }

    try {
      const { data } = await CentralCart.getUpsells(cartIds, 'CHECKOUT');
      cachedUpsells = Array.isArray(data) ? data : [];
      lastUpsellCartKey = cartKey;
      renderUpsellsFrom(cachedUpsells);
    } catch {
      upsellContainer.innerHTML = '';
    }
  }

  function renderUpsellsFrom(suggestions) {
    if (!upsellContainer) return;
    const suggestionIds = new Set(suggestions.map((s) => s.id));

    upsellFieldsById.clear();
    suggestions.forEach((s) =>
      upsellFieldsById.set(s.id, Array.isArray(s.fields) ? s.fields : []),
    );

    alternativesByTrigger = new Map();
    suggestions
      .filter(
        (s) =>
          s.upsell &&
          s.upsell.type === 'ALTERNATIVE' &&
          s.upsell.upsell_trigger_id &&
          !s.upsell.in_cart,
      )
      .forEach((s) => {
        const tid = s.upsell.upsell_trigger_id;
        const arr = alternativesByTrigger.get(tid) || [];
        arr.push(s);
        alternativesByTrigger.set(tid, arr);
      });

    const sectionSuggestions = suggestions.filter(
      (s) => !(s.upsell && s.upsell.type === 'ALTERNATIVE'),
    );

    const extraInCart = (Cart.getPackages() || [])
      .filter(
        (p) =>
          p.cart_item &&
          p.cart_item.is_upsell &&
          isUpsellAddon(p.cart_item.upsell_type) &&
          !suggestionIds.has(p.id),
      )
      .map(buildCartUpsellCard);

    const items = [...sectionSuggestions, ...extraInCart];

    items.forEach((it) => {
      if (!upsellOrder.has(it.id)) upsellOrder.set(it.id, upsellOrderSeq++);
    });
    items.sort((a, b) => upsellOrder.get(a.id) - upsellOrder.get(b.id));

    const qtyById = new Map((Cart.get() || []).map((i) => [parseInt(i.id), i.quantity]));
    items.forEach((it) => {
      if (it.upsell && it.upsell.in_cart) {
        it.cart_item = { id: it.id, quantity: qtyById.get(it.id) || 1 };
      }
    });

    upsellContainer.innerHTML = items.length ? getUpsellSectionRender(items) : '';

    if (items.length) {
      bindUpsellAdds(upsellContainer);
      initCartActionListeners(upsellContainer);
    }

    renderPackages();

    try {
      window.lucide?.createIcons?.();
    } catch {}
  }

  function buildCartUpsellCard(cp) {
    const price = (cp.pricing && cp.pricing.price) || 0;
    const compareAt = cp.pricing ? cp.pricing.compare_at : null;
    return {
      id: cp.id,
      name: cp.name,
      image: cp.image,
      pricing: cp.pricing,
      upsell: {
        in_cart: true,
        type: null,
        upsell_trigger_id:
          cp.cart_item && cp.cart_item.upsell_trigger_id != null
            ? cp.cart_item.upsell_trigger_id
            : null,
        original_price: compareAt != null ? compareAt : price,
        has_discount: compareAt != null && compareAt > price,
      },
    };
  }

  function renderCheckoutFields() {
    const container = document.getElementById('checkout_fields');
    const fields = getScriptData('__centralcart_checkout_fields', []);
    if (!container) return;

    if (!Array.isArray(fields) || fields.length === 0) {
      container.classList.add('hidden');
      return;
    }

    let cartIds = new Set();
    const cartItems = Cart.get();
    cartIds = new Set((cartItems || []).map((i) => parseInt(i.id)));

    const applicable = fields.filter((field) => {
      const arr = Array.isArray(field.applies_to) ? field.applies_to : [];
      if (arr.includes(-1)) return true;
      if (cartIds.size === 0) return false;
      return arr.some((pid) => cartIds.has(pid));
    });

    if (applicable.length === 0) {
      container.classList.add('hidden');
      return;
    }

    container.classList.remove('hidden');
    const html = getCheckoutFieldsRender(applicable);
    container.innerHTML = html;

    CustomFields.afterRender(container);
  }

  async function applyCoupon(code) {
    if (!code) {
      if (couponError) couponError.textContent = 'Informe um cupom válido';
      return;
    }
    try {
      if (couponError) couponError.textContent = '';
      const { data } = await CentralCart.getDiscount(code);
      if (!data) {
        throw new Error(data?.message || 'Cupom inválido');
      }
      const discount = data;
      const cartIds = Cart.get().map((i) => parseInt(i.id));
      const appliesToAll = discount.applies_to.includes(-1);
      if (!appliesToAll && cartIds.length > 0) {
        const hasIneligible = cartIds.some((id) => !discount.applies_to.includes(id));
        if (hasIneligible) {
          throw new Error(
            'O cupom de desconto não é aplicável para um ou mais itens no seu carrinho.'
          );
        }
      }
      const restrictedGateways = Array.isArray(discount.gateways) ? discount.gateways : [];
      if (restrictedGateways.length > 0) {
        const selectedGateway = Checkout?.getSelectedGateway?.() || null;
        if (!selectedGateway || !restrictedGateways.includes(selectedGateway)) {
          throw new Error(
            'Este cupom não é válido para o meio de pagamento selecionado.'
          );
        }
      }
      appliedDiscount = discount;
      localStorage.setItem('cart-discount', JSON.stringify({ coupon: discount.coupon, discount }));
      setCouponButtonState('remove');
      renderPackages();
    } catch (err) {
      if (couponError)
        couponError.textContent = err?.data?.errors?.[0]?.message || err?.message || 'Não foi possível aplicar este cupom';
      appliedDiscount = null;
      localStorage.removeItem('cart-discount');
      setCouponButtonState('apply');
      updatePricingUI();
    }
  }

  function removeCoupon() {
    appliedDiscount = null;
    localStorage.removeItem('cart-discount');
    setCouponButtonState('apply');
    if (couponError) couponError.textContent = '';
    if (couponInput) couponInput.value = '';
    updatePricingUI();
  }

  async function restoreCoupon() {
    try {
      const raw = localStorage.getItem('cart-discount');
      if (!raw) return;
      const saved = JSON.parse(raw);
      if (couponInput && saved?.coupon) couponInput.value = saved.coupon;
      await applyCoupon(saved?.coupon);
    } catch {}
  }

  async function init() {
    try {
      await window.Cart?.calculate?.();
      renderPackages();
      renderCheckoutFields();
      renderUpsells();
      await restoreCoupon();
    } catch (err) {}
  }

  couponButton?.addEventListener('click', async () => {
    if (appliedDiscount) {
      removeCoupon();
      return;
    }
    await applyCoupon(couponInput?.value?.trim());
  });

  init();

  document.addEventListener('cart:updated', () => {
    renderPackages();
    renderCheckoutFields();
    renderUpsells();
  });

  document.addEventListener('gateway:changed', () => {
    if (
      appliedDiscount &&
      Array.isArray(appliedDiscount.gateways) &&
      appliedDiscount.gateways.length > 0
    ) {
      const selectedGateway = Checkout?.getSelectedGateway?.() || null;
      if (!selectedGateway || !appliedDiscount.gateways.includes(selectedGateway)) {
        appliedDiscount = null;
        localStorage.removeItem('cart-discount');
        setCouponButtonState('apply');
        if (couponError)
          couponError.textContent =
            'Este cupom não é válido para o meio de pagamento selecionado.';
        updatePricingUI();
        return;
      }
    }
    updatePricingUI();
  });
})();

(function initCheckoutSubmit() {
  if (!checkoutElement) return;

  const payButton = checkoutElement.querySelector('#pay-button');
  if (!payButton) return;

  function setLoading(state) {
    try {
      if (state) {
        payButton.setAttribute('disabled', 'true');
        payButton.setAttribute('aria-busy', 'true');
        payButton.classList.add('opacity-80');

        if (!payButton.dataset.originalHtml) {
          payButton.dataset.originalHtml = payButton.innerHTML;
        }

        payButton.innerHTML = `<div class="flex items-center justify-center gap-2">${Spinner({
          size: 6,
        })}</div>`;
      } else {
        payButton.removeAttribute('disabled');
        payButton.removeAttribute('aria-busy');
        payButton.classList.remove('opacity-80');

        if (payButton.dataset.originalHtml) {
          payButton.innerHTML = payButton.dataset.originalHtml;
        }
      }
    } catch {}
  }

  payButton.addEventListener('click', async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const termsCheckbox = checkoutElement.querySelector('#terms-checkbox');
      if (!termsCheckbox?.checked) {
        toast.error('Você deve aceitar os termos e condições para continuar.');
        return;
      }

      const gateway = Checkout?.getSelectedGateway?.();
      const name = checkoutElement.querySelector('input[name="client_name"]')?.value?.trim();
      const email = checkoutElement.querySelector('input[name="client_email"]')?.value?.trim();
      const discord = checkoutElement.querySelector('input[name="client_discord"]')?.value?.trim();
      const document = checkoutElement
        .querySelector('input[name="client_document"]')
        ?.value?.trim();
      let phone = '';
      const phoneWrapperEl = checkoutElement.querySelector('#phone-field-wrapper');
      if (phoneWrapperEl && !phoneWrapperEl.classList.contains('hidden')) {
        const rawPhone = checkoutElement.querySelector('input[name="client_phone"]')?.value?.trim();
        if (rawPhone) {
          phone = PhoneInput.toE164(rawPhone, PhoneInput.getCountryCode());
        }
      }

      const rawCart = Cart.get() || [];
      const parsedCart = rawCart.map((item) => ({
        package_id: parseInt(item.id),
        quantity: parseInt(item.quantity || 1, 10),
        fields: item.fields || {},
        is_upsell: item.is_upsell || false,
        upsell_trigger_id: item.upsell_trigger_id ?? null,
      }));

      let coupon;
      try {
        const saved = JSON.parse(localStorage.getItem('cart-discount') || 'null');
        coupon = saved?.coupon;
      } catch {}

      let clientAddress;
      const addressEl = checkoutElement.querySelector('#address-section');
      if (addressEl && !addressEl.classList.contains('hidden')) {
        const cep = addressEl.querySelector('input[name="address_cep"]')?.value?.trim();
        const street = addressEl.querySelector('input[name="address_street"]')?.value?.trim();
        const number = addressEl.querySelector('input[name="address_number"]')?.value?.trim();
        const complement = addressEl.querySelector('input[name="address_complement"]')?.value?.trim();
        const neighborhood = addressEl.querySelector('input[name="address_neighborhood"]')?.value?.trim();
        const city = addressEl.querySelector('input[name="address_city"]')?.value?.trim();
        const state = addressEl.querySelector('input[name="address_state"]')?.value?.trim();

        if (!cep || !street || !number || !neighborhood || !city || !state) {
          toast.error('Preencha todos os campos de endereço obrigatórios.');
          return;
        }

        clientAddress = { cep, street, number, complement, neighborhood, city, state };
      }

      const payload = {
        gateway,
        client_email: email,
        client_name: name,
        client_phone: phone,
        fields: collectCheckoutFields(),
        client_discord: discord,
        terms: termsCheckbox.checked,
      };

      if (window.document.getElementById('use-credit')?.checked) payload.use_credit = true;

      if (clientAddress) payload.client_address = clientAddress;
      if (document) payload.client_document = document;
      if (coupon) payload.coupon = coupon;
      if (parsedCart && parsedCart.length) payload.cart = parsedCart;

      if (gateway === 'CREDITCARD') {
        const result = await CreditCardHandler.generateToken();
        if (result.payment_token) payload.payment_token = result.payment_token;
        if (result.card) payload.card = result.card;
        payload.installments = CreditCardHandler.getInstallments();
      }

      const { data } = await CentralCart.checkout(payload);

      const { checkout_url, order_id, order_token, status } = data;

      const cartContents = Cart.getPackages().map((pkg) => ({
        id: pkg.id,
        name: pkg.name,
        quantity: pkg.quantity,
        price: pkg.pricing.price,
      }));

      CentralCart.track('initiate_checkout', {
        value: Cart.calculateTotal(),
        currency: store.currency,
        transaction_id: order_id,
        contents: cartContents,
      });

      Cart.clear();

      if (status === 'APPROVED') {
        location.href = `/order/${order_id}?t=${order_token}`;
      } else {
        if (gateway === 'PIX') {
          location.href = `/payment/${order_id}?t=${order_token}`;
        } else {
          location.href = checkout_url;
        }
      }
    } catch (err) {
      const msg =
        err?.data?.errors?.[0]?.message ||
        err?.message ||
        'Não foi possível processar o seu pedido.';
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  });
})();

(function initCheckoutAutofill() {
  if (!checkoutElement) return;

  const STORAGE_KEY = 'checkout-autofill';

  const SAFE_FIELDS = [
    'client_name',
    'client_email',
    'client_document',
    'client_phone',
    'address_cep',
    'address_street',
    'address_number',
    'address_complement',
    'address_neighborhood',
    'address_city',
    'address_state',
  ];

  const fieldsContainer = document.getElementById('checkout_fields');

  function load() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}') || {};
    } catch {
      return {};
    }
  }

  function persist(data) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch {}
  }

  function inputFor(name) {
    const el = checkoutElement.querySelector(`[name="${name}"]`);
    if (!el || el.closest('#creditcard-form')) return null;
    return el;
  }

  function readCustomFields() {
    const result = {};
    if (!fieldsContainer) return result;

    fieldsContainer.querySelectorAll('[data-field-id]').forEach((element) => {
      const fieldId = element.getAttribute('data-field-id');
      const fieldType = element.getAttribute('data-field-type');
      if (!fieldId) return;

      if (fieldType === 'SELECT') {
        const select = element.querySelector('select');
        if (select && select.value) result[fieldId] = select.value;
      } else if (fieldType === 'ROBLOX') {
        const value = element.getAttribute('data-value') || '';
        if (value) result[fieldId] = value;
      } else {
        const input = element.querySelector('input');
        const value = (input?.value || '').trim();
        if (value) result[fieldId] = value;
      }
    });

    return result;
  }

  function save() {
    const data = { fields: {}, custom: {} };

    SAFE_FIELDS.forEach((name) => {
      const el = inputFor(name);
      if (!el || el.readOnly) return;
      const value = (el.value || '').trim();
      if (value) data.fields[name] = value;
    });

    data.custom = readCustomFields();
    persist(data);
  }

  function fill(el, value) {
    if (!el || el.readOnly) return;
    if ((el.value || '').trim()) return;
    el.value = value;
  }

  function restoreStatic() {
    const fields = load().fields || {};
    SAFE_FIELDS.forEach((name) => {
      if (!(name in fields)) return;
      fill(inputFor(name), fields[name]);
    });
  }

  function restoreCustom() {
    const custom = load().custom || {};
    if (!fieldsContainer) return;

    fieldsContainer.querySelectorAll('[data-field-id]').forEach((element) => {
      const fieldId = element.getAttribute('data-field-id');
      const fieldType = element.getAttribute('data-field-type');
      if (!fieldId || !(fieldId in custom)) return;

      const value = custom[fieldId];
      if (fieldType === 'SELECT') {
        const select = element.querySelector('select');
        if (select && !select.value) select.value = value;
      } else if (fieldType === 'ROBLOX') {
        const input = element.querySelector('input');
        if (input && !(input.value || '').trim()) {
          input.value = value;
          element.setAttribute('data-value', value);
        }
      } else {
        fill(element.querySelector('input'), value);
      }
    });
  }

  function onEdit(e) {
    if (e.target && e.target.closest && e.target.closest('#creditcard-form')) return;
    save();
  }
  checkoutElement.addEventListener('input', onEdit);
  checkoutElement.addEventListener('change', onEdit);

  restoreStatic();
  restoreCustom();

  if (fieldsContainer) {
    new MutationObserver(() => restoreCustom()).observe(fieldsContainer, {
      childList: true,
    });
  }
})();
