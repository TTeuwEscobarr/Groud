const packageWrapper = document.querySelector('.package-wrapper');
let pendingAdd = null; // { redirect: boolean }

// Update visible package info on the page
function updatePackageView(packageData) {
  if (!packageData) return;
  const nameEl = document.getElementById('package-name');
  const descriptionEl = document.getElementById('package-description');
  const imgEl = document.getElementById('package-image');
  const gallery = window.PackageGallery;
  const priceEl = document.getElementById('package-price');
  const compareAtEl = document.getElementById('package-compare-at');
  const percentDiscountContainerEl = document.getElementById('package-percent-discount-container');
  const percentDiscountEl = document.getElementById('package-percent-discount');
  const stockEl = document.getElementById('package-stock');
  const salesEl = document.getElementById('package-sales');
  const dialogTitleEl = document.getElementById('dialog-custom-fields-title');
  const purchaseButtonEl = document.getElementById('purchase-button');
  const addToCartButtonEl = document.getElementById('add-to-cart-button');

  if (nameEl && packageData.name) nameEl.textContent = packageData.name;
  if (dialogTitleEl && packageData.name) dialogTitleEl.textContent = packageData.name;
  if (descriptionEl && packageData.description) descriptionEl.innerHTML = packageData.description;
  if (gallery && typeof gallery.render === 'function') {
    const images =
      Array.isArray(packageData.images) && packageData.images.length
        ? packageData.images
        : packageData.image
          ? [packageData.image]
          : [];
    gallery.render(images, packageData.name);
  } else if (imgEl && packageData.image) {
    imgEl.src = packageData.image;
    imgEl.alt = packageData.name;
  }
  if (priceEl && packageData.pricing && typeof packageData.pricing.price === 'number') {
    priceEl.textContent = CentralCart.formatPrice(packageData.pricing.price, store.currency);
  }
  if (compareAtEl) {
    if (packageData.pricing && typeof packageData.pricing.compare_at === 'number') {
      compareAtEl.style.display = '';
      compareAtEl.textContent = CentralCart.formatPrice(
        packageData.pricing.compare_at,
        store.currency
      );
    } else {
      compareAtEl.style.display = 'none';
    }
  }
  if (percentDiscountContainerEl && percentDiscountEl) {
    if (packageData.pricing.percent_discount) {
      percentDiscountContainerEl.style.display = 'flex';
      percentDiscountEl.textContent = Math.abs(packageData.pricing.percent_discount).toFixed(0);
    } else {
      percentDiscountContainerEl.style.display = 'none';
    }
  }
  if (stockEl) {
    const qty =
      packageData.stock && packageData.stock.quantity !== null
        ? packageData.stock.quantity
        : '100+';
    stockEl.textContent = `${qty} em estoque`;
  }
  if (salesEl) {
    const sales = packageData.sales || 0;
    salesEl.textContent = `${sales} venda${sales > 1 ? 's' : ''}`;
    salesEl.classList.toggle('hidden', sales <= 1);
  }
  if (purchaseButtonEl) {
    purchaseButtonEl.disabled = !packageData.stock.available;
  }
  if (addToCartButtonEl) {
    addToCartButtonEl.disabled = !packageData.stock.available;
  }
}

(function initPackageGallery() {
  const root = document.getElementById('package-gallery');
  const sliderEl = document.getElementById('package-gallery-slider');
  if (!root || !sliderEl) return;

  const thumbsEl = document.getElementById('package-gallery-thumbs');
  const prevBtn = root.querySelector('[data-gallery-prev]');
  const nextBtn = root.querySelector('[data-gallery-next]');
  const fallback = root.getAttribute('data-fallback-src') || '';
  const fixedAspect = root.getAttribute('data-fixed-aspect') === '1';

  let instance = null;

  function escapeAttr(value) {
    return String(value || '').replace(/"/g, '&quot;');
  }

  function slideCount() {
    return sliderEl.querySelectorAll('.keen-slider__slide').length;
  }

  function thumbClass(active) {
    return (
      'relative size-16 shrink-0 overflow-hidden rounded-md border-2 transition ' +
      (active ? 'border-primary' : 'border-transparent opacity-60 hover:opacity-100')
    );
  }

  function buildSlides(images, name) {
    const list = (Array.isArray(images) ? images : []).filter(Boolean);
    const srcs = list.length ? list : [fallback].filter(Boolean);
    const alt = escapeAttr(name);

    const imgClass = fixedAspect ? 'w-full h-full object-cover' : 'w-full h-auto';

    sliderEl.innerHTML = srcs
      .map(
        (src, i) =>
          '<div class="keen-slider__slide">' +
          '<img ' +
          (i === 0 ? 'id="package-image" ' : '') +
          'alt="' +
          alt +
          '" class="' +
          imgClass +
          '" src="' +
          escapeAttr(src) +
          '">' +
          '</div>'
      )
      .join('');
  }

  function setActiveThumb(active) {
    if (!thumbsEl) return;
    thumbsEl.querySelectorAll('[data-gallery-thumb]').forEach((thumb, i) => {
      thumb.className = thumbClass(i === active);
    });
    const el = thumbsEl.children[active];
    if (el) el.scrollIntoView({ block: 'nearest', inline: 'center' });
  }

  function buildThumbs() {
    if (!thumbsEl) return;

    const imgs = Array.from(sliderEl.querySelectorAll('.keen-slider__slide img'));

    if (imgs.length <= 1) {
      thumbsEl.innerHTML = '';
      thumbsEl.classList.add('hidden');
      return;
    }

    thumbsEl.classList.remove('hidden');
    thumbsEl.innerHTML = imgs
      .map(
        (img, i) =>
          '<button type="button" data-gallery-thumb="' +
          i +
          '" aria-label="Ver imagem ' +
          (i + 1) +
          '" class="' +
          thumbClass(i === 0) +
          '"><img src="' +
          escapeAttr(img.getAttribute('src') || '') +
          '" alt="" loading="lazy" class="h-full w-full object-cover"></button>'
      )
      .join('');
  }

  function destroy() {
    if (instance) {
      instance.destroy();
      instance = null;
    }
    sliderEl.classList.remove('is-ready');
  }

  function create() {
    const count = slideCount();
    const many = count > 1;

    sliderEl.classList.toggle('aspect-video', fixedAspect);

    [prevBtn, nextBtn].forEach((btn) => {
      if (btn) btn.classList.toggle('hidden', !many);
    });

    buildThumbs();

    if (window.lucide) window.lucide.createIcons();

    if (!many || typeof KeenSlider === 'undefined') return;

    instance = new KeenSlider(
      sliderEl,
      {
        loop: true,
        renderMode: 'performance',
        slides: { perView: 1 },
      },
      [autoplay(10000)]
    );

    sliderEl.classList.add('is-ready');

    instance.on('slideChanged', (s) => setActiveThumb(s.track.details.rel));
  }

  function autoplay(interval) {
    return (slider) => {
      let timeout;
      let hovered = false;

      function clear() {
        clearTimeout(timeout);
      }

      function schedule() {
        clear();
        if (hovered) return;
        timeout = setTimeout(() => slider.next(), interval);
      }

      slider.on('created', () => {
        slider.container.addEventListener('mouseenter', () => {
          hovered = true;
          clear();
        });
        slider.container.addEventListener('mouseleave', () => {
          hovered = false;
          schedule();
        });
        schedule();
      });

      slider.on('dragStarted', clear);
      slider.on('animationEnded', schedule);
      slider.on('updated', schedule);
      slider.on('destroyed', clear);
    };
  }

  function render(images, name) {
    destroy();
    buildSlides(images, name);
    create();
  }

  if (prevBtn) prevBtn.addEventListener('click', () => instance && instance.prev());
  if (nextBtn) nextBtn.addEventListener('click', () => instance && instance.next());
  if (thumbsEl) {
    thumbsEl.addEventListener('click', (e) => {
      const thumb = e.target.closest('[data-gallery-thumb]');
      if (thumb && instance) instance.moveToIdx(Number(thumb.getAttribute('data-gallery-thumb')));
    });
  }

  window.PackageGallery = { render };

  create();
})();

// ----- Custom fields DOM wiring & helpers (moved from inline template) -----
(function defineCustomFieldsHelpers() {
  function ensureLucide() {
    if (window.lucide) window.lucide.createIcons();
  }

  function afterRender(container) {
    if (!container) return;

    // Clear error state on input
    container.querySelectorAll('input').forEach((input) => {
      input.addEventListener('input', () => {
        input.removeAttribute('data-state');
        const fid = input.getAttribute('id');
        if (fid) {
          const err = document.getElementById(`error-${fid}`);
          if (err) {
            err.textContent = '';
            err.classList.add('hidden');
          }
        }
      });
    });

    // Clear error state on select
    container.querySelectorAll('select').forEach((select) => {
      select.addEventListener('change', () => {
        select.removeAttribute('data-state');
        const fid = select.getAttribute('id');
        if (fid) {
          const err = document.getElementById(`error-${fid}`);
          if (err) {
            err.textContent = '';
            err.classList.add('hidden');
          }
        }
      });
    });

    // Keep ROBLOX data-value in sync
    container.querySelectorAll('[data-field-type="ROBLOX"]').forEach((element) => {
      const input = element.querySelector('input');
      if (!input) return;
      const setValue = () => {
        const value = (input.value || '').trim();
        if (value) element.setAttribute('data-value', value);
        else element.removeAttribute('data-value');
      };
      input.addEventListener('input', setValue);
      input.addEventListener('blur', setValue);
    });

    // ROBLOX dynamic search and select using useTyping (from scripts/main.js)
    container.querySelectorAll('[data-field-type="ROBLOX"]').forEach((element) => {
      const fieldName = element.getAttribute('data-field-id');
      if (!fieldName) return;
      const input = element.querySelector(`#${CSS.escape(fieldName)}`);
      if (!input) return;

      const resultContainer = document.getElementById(`roblox-result-${fieldName}`);
      const loaderContainer = document.getElementById(`roblox-loader-${fieldName}`);
      const inputAvatar = document.getElementById(`roblox-input-avatar-${fieldName}`);
      const avatarEl = document.getElementById(`roblox-avatar-${fieldName}`);
      const nameEl = document.getElementById(`roblox-name-${fieldName}`);
      const usernameEl = document.getElementById(`roblox-username-${fieldName}`);
      const selectBtn = document.getElementById(`roblox-select-${fieldName}`);
      const errorEl = document.getElementById(`error-${fieldName}`);

      if (typeof useTyping === 'function') {
        useTyping(input, {
          onStart: () => {
            if (resultContainer) resultContainer.classList.add('hidden');
            if (loaderContainer) loaderContainer.classList.remove('hidden');
            const searchIcon = element.querySelector('[data-lucide="search"]');
            if (searchIcon) searchIcon.classList.remove('hidden');
            if (inputAvatar) inputAvatar.classList.add('hidden');
            if (errorEl) {
              errorEl.classList.add('hidden');
              errorEl.textContent = '';
            }
            input.removeAttribute('data-state');
          },
          onStop: async (value) => {
            const username = (value || '').trim();
            if (!username || username.length < 3) {
              if (loaderContainer) loaderContainer.classList.add('hidden');
              if (errorEl) {
                errorEl.textContent = '';
                errorEl.classList.add('hidden');
              }
              return;
            }

            try {
              const res = await CentralCart.getRoblox(username);
              const data = res && res.data ? res.data : null;
              if (!data) {
                if (errorEl) {
                  errorEl.textContent = 'Usuário não encontrado.';
                  errorEl.classList.remove('hidden');
                }
                input.setAttribute('data-state', 'error');
                return;
              }

              if (avatarEl) avatarEl.src = data.avatar_url || '';
              if (nameEl) nameEl.textContent = data.display_name || '';
              if (usernameEl) usernameEl.textContent = data.username ? `@${data.username}` : '';

              if (resultContainer) resultContainer.classList.remove('hidden');
              if (errorEl) {
                errorEl.textContent = '';
                errorEl.classList.add('hidden');
              }
              input.removeAttribute('data-state');
            } catch (e) {
              if (errorEl) {
                errorEl.textContent = 'Usuário não encontrado.';
                errorEl.classList.remove('hidden');
              }
              input.setAttribute('data-state', 'error');
            } finally {
              if (loaderContainer) loaderContainer.classList.add('hidden');
            }
          },
          delay: 500,
        });
      }

      if (selectBtn) {
        selectBtn.addEventListener('click', () => {
          if (resultContainer) resultContainer.classList.add('hidden');
          const searchIcon = element.querySelector('[data-lucide="search"]');
          if (avatarEl && avatarEl.src && inputAvatar) {
            inputAvatar.src = avatarEl.src;
            inputAvatar.classList.remove('hidden');
            if (searchIcon) searchIcon.classList.add('hidden');
            input.classList.add('pl-8');
          }
          const value = (input.value || '').trim();
          if (value) element.setAttribute('data-value', value);
          if (errorEl) {
            errorEl.textContent = '';
            errorEl.classList.add('hidden');
          }
          input.removeAttribute('data-state');
        });
      }
    });

    ensureLucide();
  }

  function collect() {
    const container = document.getElementById('custom-fields-fields');
    if (!container) return {};
    const fields = {};
    let hasError = false;

    container.querySelectorAll('[data-field-id]').forEach((element) => {
      const customId = element.getAttribute('data-field-id');
      const type = element.getAttribute('data-field-type');

      if (type === 'ROBLOX') {
        const value = element.getAttribute('data-value') || '';
        const input = element.querySelector('input');
        const errorEl = document.getElementById(`error-${customId}`);
        const required = input && input.getAttribute('data-required') === 'true';
        if (required && !value) {
          if (errorEl) {
            errorEl.textContent = 'Este campo é obrigatório.';
            errorEl.classList.remove('hidden');
          }
          input.setAttribute('data-state', 'error');
          hasError = true;
          return;
        }
        fields[customId] = value;
      } else if (type === 'SELECT') {
        const select = element.querySelector('select');
        if (!select) return;
        const required = select.getAttribute('data-required') === 'true';
        const value = select.value;
        const errorEl = document.getElementById(`error-${customId}`);
        if (required && !value) {
          if (errorEl) {
            errorEl.textContent = 'Este campo é obrigatório.';
            errorEl.classList.remove('hidden');
          }
          select.setAttribute('data-state', 'error');
          hasError = true;
          return;
        }
        if (errorEl) {
          errorEl.textContent = '';
          errorEl.classList.add('hidden');
        }
        select.removeAttribute('data-state');
        fields[customId] = value;
      } else {
        const input = element.querySelector('input');
        if (!input) return;
        const required = input.getAttribute('data-required') === 'true';
        const value = input.value.trim();
        const errorEl = document.getElementById(`error-${customId}`);
        if (required && !value) {
          if (errorEl) {
            errorEl.textContent = 'Este campo é obrigatório.';
            errorEl.classList.remove('hidden');
          }
          input.setAttribute('data-state', 'error');
          hasError = true;
          return;
        }
        if (errorEl) {
          errorEl.textContent = '';
          errorEl.classList.add('hidden');
        }
        input.removeAttribute('data-state');
        fields[customId] = value;
      }
    });

    if (hasError) return null;
    return fields;
  }

  function hasAny() {
    const container = document.getElementById('custom-fields-fields');
    if (!container) return false;
    return container.querySelector('[data-field-id]') !== null;
  }

  window.CustomFields = Object.assign(window.CustomFields || {}, {
    afterRender,
    collect,
    hasAny,
  });
})();

// Apply a variation: update dataset, URL and visible info
function applyVariation(variation) {
  if (!packageWrapper || !variation) return;
  packageWrapper.dataset.packageId = String(variation.id);
  const url = new URL(window.location.href);
  url.searchParams.set('variation', variation.slug || variation.id);
  window.history.replaceState({}, '', url.toString());
  updatePackageView(variation);
  updateCustomFields(variation.fields || []);
}

// Entrypoint
(function initPackagePage() {
  if (!packageWrapper) return;

  const isParentAttr = packageWrapper.dataset.isVariationParent;
  const isParent = isParentAttr === 'true' || isParentAttr === '1';

  const list = getScriptData('__centralcart_package_variations', []);

  const initialFields = getScriptData('__centralcart_package_fields', []);
  updateCustomFields(initialFields);

  // Wire confirm button inside dialog
  const confirmBtn = document.getElementById('custom-fields-confirm');
  if (confirmBtn) {
    confirmBtn.addEventListener('click', () => {
      const wrapper = document.querySelector('.package-wrapper');
      if (!wrapper) return;
      const selectedId = parseInt(wrapper.dataset.packageId);
      const fields = collectCustomFields();
      if (fields === null) return; // validation failed
      addToCart({
        packageId: selectedId,
        fields,
        openDrawer: !(pendingAdd && pendingAdd.redirect),
      });
      if (pendingAdd && pendingAdd.redirect) window.location.href = '/checkout';
      if (typeof closeDialog === 'function') closeDialog('custom-fields');
      pendingAdd = null;
    });
  }

  if (!isParent || list.length === 0) return;

  const url = new URL(window.location.href);
  const queryVar = url.searchParams.get('variation');

  let selected = null;
  if (queryVar) {
    const asNum = parseInt(queryVar);
    selected = list.find((v) => v.id === asNum) || list.find((v) => v.slug === queryVar) || null;
  }
  if (!selected) selected = list[0];
  applyVariation(selected);

  // Mark selected in UI
  const markSelected = (id) => {
    document.querySelectorAll('[data-action="select-variation"]').forEach((el) => {
      const vid = parseInt(el.getAttribute('data-variation-id'));
      const isSel = vid === id;
      el.setAttribute('data-selected', String(isSel));
    });
  };
  markSelected(selected.id);

  // Click listeners
  document.querySelectorAll('[data-action="select-variation"]').forEach((el) => {
    el.addEventListener('click', () => {
      const vid = parseInt(el.getAttribute('data-variation-id'));
      const v = list.find((x) => x.id === vid);
      if (v) {
        applyVariation(v);
        markSelected(v.id);
      }
    });
  });
})();

function cartAdd(redirect = false) {
  const wrapper = document.querySelector('.package-wrapper');
  if (!wrapper) return;
  const selectedId = parseInt(wrapper.dataset.packageId);
  if (hasCustomFields()) {
    pendingAdd = { redirect };
    if (typeof openDialog === 'function') openDialog('custom-fields');
    return;
  }
  addToCart({ packageId: selectedId, fields: {}, openDrawer: !redirect });
  if (redirect) window.location.href = '/checkout';
}

// ----- Custom fields helpers (delegating to inline template functions) -----
function updateCustomFields(fields) {
  return window.CustomFields.render(fields);
}

function collectCustomFields() {
  return window.CustomFields.collect();
}

function hasCustomFields() {
  return window.CustomFields.hasAny();
}
