const base_url = window.location.origin;

function Spinner({ size = 5 }) {
  return `
  <svg aria-hidden="true" id="spinner" class="size-${size} text-white/30 animate-spin fill-white" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="currentColor"/>
      <path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" fill="currentFill"/>
  </svg>
  `;
}

function useTyping(inputElement, { onStart, onStop, delay = 600 }) {
  let typingTimer;
  let isTyping = false;

  const handleInput = () => {
    const value = inputElement.value;

    if (!isTyping) {
      isTyping = true;
      onStart?.(value);
    }

    clearTimeout(typingTimer);
    typingTimer = setTimeout(() => {
      isTyping = false;
      onStop?.(value);
    }, delay);
  };

  inputElement.addEventListener('input', handleInput);

  return () => {
    inputElement.removeEventListener('input', handleInput);
    clearTimeout(typingTimer);
  };
}

function callNotification(content, status) {
  const html = `
<div class="flex items-center gap-2">
  ${
    status === 'error'
      ? '<i data-lucide="circle-x" class="text-red-500 me-0.5 min-size-4 inline"></i>'
      : '<i data-lucide="circle-check" class="text-green-500 me-0.5 min-size-4 inline"></i>'
  }
  <p class="text-sm">${content}</p>
</div>
`;

  Toastify({
    style: {
      background: `rgb(var(--background))`,
      border: 'solid 1px rgb(var(--border))',
      borderRadius: '8px',
      boxShadow: 'none',
      maxWidth: '520px',
      minWidth: '310px',
      width: 'fit-content',
      display: 'flex',
      gap: '16px',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '12px 12px',
    },
    escapeMarkup: false,
    text: html,
    duration: 3000,
    close: true,
    gravity: 'bottom',
    position: 'right',
  }).showToast();

  lucide.createIcons();
}

const toast = {
  success: function (content) {
    callNotification(content, 'success');
  },
  error: function (content) {
    callNotification(content, 'error');
  },
};

function getScriptData(id, fallback = []) {
  try {
    const element = document.getElementById(id);
    return JSON.parse(element?.textContent || JSON.stringify(fallback));
  } catch {
    return fallback;
  }
}

function toggleMobileSearch() {
  const container = document.getElementById('mobile-search-container');
  if (!container) return;
  container.classList.toggle('hidden');

  if (!container.classList.contains('hidden')) {
    const input = document.getElementById('search-bar-mobile');
    if (input) input.focus();
  } else {
    const result = document.getElementById('search-result-mobile');
    if (result) result.classList.add('hidden');
  }
}

function handleSearch(inputSelector, resultSelector) {
  const inputElement = document.querySelector(inputSelector);
  const resultElement = document.querySelector(resultSelector);

  if (!inputElement || !resultElement) return;

  inputElement.addEventListener('click', () => {
    if (
      inputElement.value.trim() &&
      resultElement.children.length &&
      !resultElement.innerHTML.includes('flex items-center justify-center')
    ) {
      resultElement.classList.remove('hidden');
    }
  });

  inputElement.addEventListener('focus', () => {
    if (
      inputElement.value.trim() &&
      resultElement.children.length &&
      !resultElement.innerHTML.includes('flex items-center justify-center')
    ) {
      resultElement.classList.remove('hidden');
    }
  });

  useTyping(inputElement, {
    onStart: () => {
      resultElement.innerHTML = `<div class="p-3 flex items-center justify-center">${Spinner({
        size: 10,
      })}</div>`;
      resultElement.classList.remove('hidden');
    },
    onStop: async (content) => {
      if (!content) {
        resultElement.classList.add('hidden');
        return;
      }

      try {
        const response = await fetch(
          `${base_url}/search?q=${encodeURIComponent(
            content
          )}&page=1&limit=10&bar=true&include_variations=true&load_parent=true`
        );
        const data = await response.text();
        resultElement.innerHTML = CentralCart.sanitizeHTML(data);
        resultElement.classList.remove('hidden');

        if (typeof publishEvent === 'function') {
          publishEvent('search', { search: content });
        }
      } catch (error) {
        resultElement.innerHTML = '<div class="p-2 text-red-500">Erro ao buscar</div>';
        resultElement.classList.remove('hidden');
      }
    },
  });

  document.addEventListener('click', (e) => {
    if (!inputElement.contains(e.target) && !resultElement.contains(e.target)) {
      resultElement.classList.add('hidden');
    }
  });
}

function initRevealObserver() {
  const revealObserver = new IntersectionObserver(
    (entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    },
    {
      threshold: 0.1,
    }
  );

  document.querySelectorAll('.reveal-fade-up').forEach((el) => {
    revealObserver.observe(el);
  });
}

async function loadCategory(categoryId, element, currentPackage = null) {
  const url = currentPackage
    ? `/search?category_id=${categoryId}&current_package=${currentPackage}&limit=10`
    : `/search?category_id=${categoryId}&package_list=true&limit=1000`;

  const content = await fetch(url).then((res) => res.text());

  element.innerHTML = CentralCart.sanitizeHTML(content);

  if (window.lucide) lucide.createIcons();

  const similarSlider = document.getElementById('similar-packages-slider');
  if (currentPackage && similarSlider) {
    const slider = new KeenSlider(similarSlider, {
      slides: {
        perView: 5,
        spacing: 8,
      },
      breakpoints: {
        '(max-width: 1024px)': {
          slides: {
            perView: 2,
            spacing: 4,
          },
        },
      },
    });

    document.getElementById('similar-slider-prev')?.addEventListener('click', () => slider.prev());
    document.getElementById('similar-slider-next')?.addEventListener('click', () => slider.next());
  }

  initRevealObserver();
}

(() => {
  initRevealObserver();

  document.querySelectorAll('.package-list').forEach((element) => {
    new IntersectionObserver(
      (entries, observer) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            loadCategory(
              entry.target.dataset.categoryId,
              element,
              entry.target.dataset.currentPackage
            );
            observer.unobserve(entry.target);
          }
        });
      },
      {
        rootMargin: '0px 0px 0px 0px',
        threshold: 0.1,
      }
    ).observe(element);
  });
})();

(() => {
  handleSearch('#search-bar', '#search-result');
  handleSearch('#search-bar-mobile', '#search-result-mobile');
})();

(() => {
  const licenseContainers = document.querySelectorAll('.license-key[data-license-raw]');

  licenseContainers.forEach((container) => {
    const raw = container.getAttribute('data-license-raw') || '';
    const formatted = container.getAttribute('data-license-formatted') || null;

    const valueToProcess = formatted || raw;

    let parsed;

    try {
      parsed = JSON.parse(valueToProcess);
    } catch {
      const row = container.parentElement;
      if (!row) return;

      if (row.querySelector('[data-action="copy"]')) return;

      row.classList.add('flex', 'items-center', 'justify-between', 'gap-1');

      const copyBtn = document.createElement('button');
      copyBtn.type = 'button';
      copyBtn.className = 'text-xs group';
      copyBtn.setAttribute('data-action', 'copy');
      copyBtn.setAttribute('data-content', raw);
      copyBtn.setAttribute('data-is-copied', 'false');
      copyBtn.innerHTML = `
        <i data-lucide="check" class="size-3.5 hidden group-data-[is-copied=true]:block"></i>
        <i data-lucide="copy" class="size-3.5 hidden group-data-[is-copied=false]:block"></i>
      `;

      row.appendChild(copyBtn);

      if (window.lucide) {
        lucide.createIcons();
      }

      return;
    }

    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      const row = container.parentElement;
      if (!row) return;

      if (row.querySelector('[data-action="copy"]')) return;

      row.classList.add('flex', 'items-center', 'justify-between', 'gap-1');

      const copyBtn = document.createElement('button');
      copyBtn.type = 'button';
      copyBtn.className = 'text-xs group';
      copyBtn.setAttribute('data-action', 'copy');
      copyBtn.setAttribute('data-content', raw);
      copyBtn.setAttribute('data-is-copied', 'false');
      copyBtn.innerHTML = `
        <i data-lucide="check" class="size-3.5 hidden group-data-[is-copied=true]:block"></i>
        <i data-lucide="copy" class="size-3.5 hidden group-data-[is-copied=false]:block"></i>
      `;

      row.appendChild(copyBtn);

      if (window.lucide) {
        lucide.createIcons();
      }

      return;
    }

    container.innerHTML = '';
    container.classList.add('grid', 'gap-x-4', 'gap-y-3');
    container.style.gridTemplateColumns = 'repeat(auto-fit, minmax(160px, 1fr))';

    Object.entries(parsed).forEach(([label, value]) => {
      const row = document.createElement('div');
      row.className = 'space-y-1 min-w-0';

      const labelEl = document.createElement('span');
      labelEl.className = 'text-sm font-medium text-muted-foreground';
      labelEl.textContent = String(label);

      const field = document.createElement('div');
      field.className = 'flex items-center justify-between gap-2';

      const valueEl = document.createElement('span');
      valueEl.className = 'text-sm font-medium text-foreground truncate flex-1 min-w-0';
      valueEl.textContent = String(value ?? '');

      const copyBtn = document.createElement('button');
      copyBtn.type = 'button';
      copyBtn.className = 'group flex-shrink-0';
      copyBtn.setAttribute('data-action', 'copy');
      copyBtn.setAttribute('data-content', String(value ?? ''));
      copyBtn.setAttribute('data-is-copied', 'false');
      copyBtn.innerHTML = `
        <i data-lucide="check" class="size-3.5 hidden group-data-[is-copied=true]:block"></i>
        <i data-lucide="copy" class="size-3.5 hidden group-data-[is-copied=false]:block"></i>
      `;

      field.appendChild(valueEl);
      field.appendChild(copyBtn);

      row.appendChild(labelEl);
      row.appendChild(field);

      container.appendChild(row);
    });

    if (window.lucide) {
      lucide.createIcons();
    }
  });
})();

document.querySelectorAll('[data-action=copy]').forEach((element) => {
  const content = element.getAttribute('data-content');

  element.addEventListener('click', () => {
    window.navigator.clipboard.writeText(content);
    element.disabled = true;
    element.setAttribute('data-is-copied', 'true');

    setTimeout(() => {
      element.disabled = false;
      element.setAttribute('data-is-copied', 'false');
    }, 1500);

    toast.success('Conteúdo copiado com sucesso.');
  });
});

document.querySelectorAll('[data-action="copy-all-keys"]').forEach((button) => {
  button.addEventListener('click', () => {
    const licenseGroup = button.closest('[data-license-group]');
    if (!licenseGroup) return;

    const licenseKeys = Array.from(licenseGroup.querySelectorAll('.license-key[data-license-raw]'))
      .map((el) => el.getAttribute('data-license-raw') || '')
      .filter((key) => key);

    if (licenseKeys.length === 0) {
      toast.error('Nenhuma chave encontrada para copiar.');
      return;
    }

    const keysText = licenseKeys.join('\n');
    navigator.clipboard
      .writeText(keysText)
      .then(() => {
        button.disabled = true;
        button.setAttribute('data-is-copied', 'true');

        setTimeout(() => {
          button.disabled = false;
          button.setAttribute('data-is-copied', 'false');
        }, 2000);

        toast.success(`${licenseKeys.length} chave(s) copiada(s) com sucesso.`);
      })
      .catch((err) => {
        console.error(err);
        toast.error('Erro ao copiar as chaves.');
      });
  });
});

document.querySelectorAll('[data-action="download-keys"]').forEach((button) => {
  button.addEventListener('click', () => {
    const licenseGroup = button.closest('[data-license-group]');
    if (!licenseGroup) return;

    const licenseKeys = Array.from(licenseGroup.querySelectorAll('.license-key[data-license-raw]'))
      .map((el) => el.getAttribute('data-license-raw') || '')
      .filter((key) => key);

    if (licenseKeys.length === 0) {
      toast.error('Nenhuma chave encontrada para baixar.');
      return;
    }

    const packageName = button.getAttribute('data-package-name') || 'Produto';

    const keysText = licenseKeys.join('\n');
    const blob = new Blob([keysText], { type: 'text/plain;charset=utf-8' });

    const url = URL.createObjectURL(blob);
    const downloadLink = document.createElement('a');
    downloadLink.href = url;
    downloadLink.download = `${licenseKeys.length}x - ${packageName}.txt`;

    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);

    URL.revokeObjectURL(url);

    button.disabled = true;
    button.setAttribute('data-is-downloaded', 'true');

    setTimeout(() => {
      button.disabled = false;
      button.setAttribute('data-is-downloaded', 'false');
    }, 2000);

    toast.success(`${licenseKeys.length} chave(s) baixada(s) com sucesso.`);
  });
});

document.querySelectorAll('[data-expandable]').forEach((wrapper) => {
  const content = wrapper.querySelector('[data-expandable-content]');
  const fade = wrapper.querySelector('[data-expandable-fade]');
  const button = wrapper.querySelector('[data-action="toggle-expandable"]');
  const label = wrapper.querySelector('[data-expandable-label]');
  const chevron = wrapper.querySelector('[data-expandable-chevron]');
  if (!content || !button) return;

  const collapsedHeight = parseInt(wrapper.getAttribute('data-collapsed-height') || '240', 10);

  if (content.scrollHeight <= collapsedHeight + 8) {
    button.classList.add('hidden');
    if (fade) fade.classList.add('hidden');
    return;
  }

  const collapse = () => {
    content.style.maxHeight = collapsedHeight + 'px';
    if (fade) fade.classList.remove('hidden');
    if (label) label.textContent = 'Expandir';
    if (chevron) chevron.classList.remove('rotate-180');
    button.setAttribute('data-is-expanded', 'false');
  };

  const expand = () => {
    content.style.maxHeight = content.scrollHeight + 'px';
    if (fade) fade.classList.add('hidden');
    if (label) label.textContent = 'Recolher';
    if (chevron) chevron.classList.add('rotate-180');
    button.setAttribute('data-is-expanded', 'true');
  };

  collapse();

  button.addEventListener('click', () => {
    if (button.getAttribute('data-is-expanded') === 'true') {
      collapse();
    } else {
      expand();
    }
  });
});

/* Sidebar categories handlers */
function toggleMobileCategories() {
  const dropdown = document.getElementById('mobile-categories-dropdown');
  const button = document.getElementById('mobile-category-toggle');
  if (!dropdown || !button) return;
  const isOpen = dropdown.getAttribute('data-state') === 'open';
  const nextState = isOpen ? 'closed' : 'open';
  dropdown.setAttribute('data-state', nextState);
  button.setAttribute('data-state', nextState);
}

function toggleMobileCategoryGroup(categoryId) {
  const subcategories = document.querySelector(`[data-category="${categoryId}"]`);
  if (!subcategories) return;
  const button = subcategories.previousElementSibling;
  const isOpen = subcategories.getAttribute('data-state') === 'open';
  const nextState = isOpen ? 'closed' : 'open';
  subcategories.setAttribute('data-state', nextState);
  if (button) button.setAttribute('data-state', nextState);
}

function closeMobileCategories() {
  const dropdown = document.getElementById('mobile-categories-dropdown');
  const button = document.getElementById('mobile-category-toggle');
  if (dropdown) dropdown.setAttribute('data-state', 'closed');
  if (button) button.setAttribute('data-state', 'closed');
  document
    .querySelectorAll('.mobile-category-group > button')
    .forEach((el) => el.setAttribute('data-state', 'closed'));
  document.querySelectorAll('.mobile-subcategories').forEach((sub) => {
    sub.setAttribute('data-state', 'closed');
  });
}

function toggleCategoryDropdown(catId) {
  const targetDropdown = document.querySelector(`[data-id="${catId}"]`);
  if (!targetDropdown) return;
  const targetButton = targetDropdown.previousElementSibling;
  const isOpen = targetDropdown.getAttribute('data-state') === 'open';
  const nextState = isOpen ? 'closed' : 'open';
  document.querySelectorAll('.cat-dropdown').forEach((el) => {
    if (el.dataset.id !== String(catId)) {
      el.setAttribute('data-state', 'closed');
      const button = el.previousElementSibling;
      if (button) button.setAttribute('data-state', 'closed');
    }
  });
  targetDropdown.setAttribute('data-state', nextState);
  if (targetButton) targetButton.setAttribute('data-state', nextState);
}

document.addEventListener('click', function (e) {
  const mobileToggle = document.getElementById('mobile-category-toggle');
  const mobileDropdown = document.getElementById('mobile-categories-dropdown');
  if (!mobileToggle || !mobileDropdown) return;
  if (!mobileToggle.contains(e.target) && !mobileDropdown.contains(e.target)) {
    window.closeMobileCategories();
  }
});

document.addEventListener('click', function (e) {
  if (!e.target.closest('.sidebar-categories-menu')) {
    document.querySelectorAll('.cat-dropdown').forEach((el) => {
      el.setAttribute('data-state', 'closed');
      const button = el.previousElementSibling;
      if (button) button.setAttribute('data-state', 'closed');
    });
  }
});
/* Sidebar categories handlers */


(() => {
  if (window.__numberOnlyInit) return;
  window.__numberOnlyInit = true;

  document.addEventListener("keypress", function (event) {
    var target = event.target;
    if (!(target instanceof HTMLInputElement)) return;
    if (!target.classList.contains("number-only")) return;
    if (event.key && event.key.length === 1 && !/\d/.test(event.key)) {
      event.preventDefault();
    }
  });

  document.addEventListener("input", function (event) {
    var target = event.target;
    if (!(target instanceof HTMLInputElement)) return;
    if (!target.classList.contains("number-only")) return;
    var original = target.value;
    var clean = original.replace(/\D+/g, "");
    if (clean !== original) {
      var pos = target.selectionStart;
      target.value = clean;
      try {
        var newPos = Math.max(0, (pos || 0) - (original.length - clean.length));
        target.setSelectionRange(newPos, newPos);
      } catch (e) {}
    }
  });
})();

(() => {
  if (window.__heroBannerInit) return;
  window.__heroBannerInit = true;

  function initHeroBanner() {
    const root = document.getElementById('hero-banner');
    const sliderEl = document.getElementById('hero-banner-slider');
    if (!root || !sliderEl) return;

    const dotsEl = document.getElementById('hero-banner-dots');
    const prevBtn = root.querySelector('[data-hero-prev]');
    const nextBtn = root.querySelector('[data-hero-next]');

    const slides = sliderEl.querySelectorAll('.keen-slider__slide');
    if (slides.length < 2 || typeof KeenSlider === 'undefined') return;

    function dotClass(active) {
      return (
        'h-1.5 rounded-full bg-white transition-all ' +
        (active ? 'w-5 opacity-90' : 'w-1.5 opacity-50 hover:opacity-75')
      );
    }

    function buildDots() {
      if (!dotsEl) return;

      dotsEl.innerHTML = Array.from(slides)
        .map(
          (_, i) =>
            '<button type="button" data-hero-dot="' +
            i +
            '" aria-label="Ir para o banner ' +
            (i + 1) +
            '" class="' +
            dotClass(i === 0) +
            '"></button>'
        )
        .join('');
    }

    function setActiveDot(active) {
      if (!dotsEl) return;
      dotsEl.querySelectorAll('[data-hero-dot]').forEach((dot, i) => {
        dot.className = dotClass(i === active);
      });
    }

    function autoplay(interval) {
      return (slider) => {
        let timeout;
        let hovered = false;

        function clear() {
          clearTimeout(timeout);
        }

        function schedule() {
          clear();
          if (hovered) return;
          timeout = setTimeout(() => slider.next(), interval);
        }

        slider.on('created', () => {
          slider.container.addEventListener('mouseenter', () => {
            hovered = true;
            clear();
          });
          slider.container.addEventListener('mouseleave', () => {
            hovered = false;
            schedule();
          });
          schedule();
        });

        slider.on('dragStarted', clear);
        slider.on('animationEnded', schedule);
        slider.on('updated', schedule);
        slider.on('destroyed', clear);
      };
    }

    buildDots();

    const instance = new KeenSlider(
      sliderEl,
      {
        loop: true,
        renderMode: 'performance',
        slides: { perView: 1 },
      },
      [autoplay(6000)]
    );

    sliderEl.classList.add('is-ready');

    instance.on('slideChanged', (s) => setActiveDot(s.track.details.rel));

    if (prevBtn) prevBtn.addEventListener('click', () => instance.prev());
    if (nextBtn) nextBtn.addEventListener('click', () => instance.next());

    if (dotsEl) {
      dotsEl.addEventListener('click', (e) => {
        const dot = e.target.closest('[data-hero-dot]');
        if (dot) instance.moveToIdx(Number(dot.getAttribute('data-hero-dot')));
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initHeroBanner);
  } else {
    initHeroBanner();
  }
})();
