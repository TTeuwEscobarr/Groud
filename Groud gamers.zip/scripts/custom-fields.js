// Shared Custom Fields interactions (ROBLOX, error clear, icons)
(function defineCustomFieldsShared() {
  function ensureLucide() {
    try {
      if (window.lucide && typeof window.lucide.createIcons === 'function') {
        window.lucide.createIcons();
      }
    } catch {}
  }

  function afterRender(container) {
    if (!container) return;

    // Clear error state on input
    container.querySelectorAll('input').forEach((input) => {
      input.addEventListener('input', () => {
        input.removeAttribute('data-state');
        const fid = input.getAttribute('id');
        if (fid) {
          const err = document.getElementById(`error-${fid}`);
          if (err) {
            err.textContent = '';
            err.classList.add('hidden');
          }
        }
      });
    });

    // Clear error state on select
    container.querySelectorAll('select').forEach((select) => {
      select.addEventListener('change', () => {
        select.removeAttribute('data-state');
        const fid = select.getAttribute('id');
        if (fid) {
          const err = document.getElementById(`error-${fid}`);
          if (err) {
            err.textContent = '';
            err.classList.add('hidden');
          }
        }
      });
    });

    // Keep ROBLOX data-value in sync
    container.querySelectorAll('[data-field-type="ROBLOX"]').forEach((element) => {
      const input = element.querySelector('input');
      if (!input) return;
      const setValue = () => {
        const value = (input.value || '').trim();
        if (value) element.setAttribute('data-value', value);
        else element.removeAttribute('data-value');
      };
      input.addEventListener('input', setValue);
      input.addEventListener('blur', setValue);
    });

    // ROBLOX dynamic search and select using useTyping (from scripts/main.js)
    container.querySelectorAll('[data-field-type="ROBLOX"]').forEach((element) => {
      const fieldName = element.getAttribute('data-field-id');
      if (!fieldName) return;
      const input = element.querySelector(`#${CSS.escape(fieldName)}`);
      if (!input) return;

      const resultContainer = document.getElementById(`roblox-result-${fieldName}`);
      const loaderContainer = document.getElementById(`roblox-loader-${fieldName}`);
      const inputAvatar = document.getElementById(`roblox-input-avatar-${fieldName}`);
      const avatarEl = document.getElementById(`roblox-avatar-${fieldName}`);
      const nameEl = document.getElementById(`roblox-name-${fieldName}`);
      const usernameEl = document.getElementById(`roblox-username-${fieldName}`);
      const selectBtn = document.getElementById(`roblox-select-${fieldName}`);
      const errorEl = document.getElementById(`error-${fieldName}`);

      if (typeof window.useTyping === 'function') {
        window.useTyping(input, {
          onStart: () => {
            if (resultContainer) resultContainer.classList.add('hidden');
            if (loaderContainer) loaderContainer.classList.remove('hidden');
            const searchIcon = element.querySelector('[data-lucide="search"]');
            if (searchIcon) searchIcon.classList.remove('hidden');
            if (inputAvatar) inputAvatar.classList.add('hidden');
            if (errorEl) {
              errorEl.classList.add('hidden');
              errorEl.textContent = '';
            }
            input.removeAttribute('data-state');
          },
          onStop: async (value) => {
            const username = (value || '').trim();
            if (!username || username.length < 3) {
              if (loaderContainer) loaderContainer.classList.add('hidden');
              if (errorEl) {
                errorEl.textContent = '';
                errorEl.classList.add('hidden');
              }
              return;
            }

            try {
              const res = await window.CentralCart.getRoblox(username);
              const data = res && res.data ? res.data : null;
              if (!data) {
                if (errorEl) {
                  errorEl.textContent = 'Usuário não encontrado.';
                  errorEl.classList.remove('hidden');
                }
                input.setAttribute('data-state', 'error');
                return;
              }

              if (avatarEl) avatarEl.src = data.avatar_url || '';
              if (nameEl) nameEl.textContent = data.display_name || '';
              if (usernameEl) usernameEl.textContent = data.username ? `@${data.username}` : '';

              if (resultContainer) resultContainer.classList.remove('hidden');
              if (errorEl) {
                errorEl.textContent = '';
                errorEl.classList.add('hidden');
              }
              input.removeAttribute('data-state');
            } catch (e) {
              if (errorEl) {
                errorEl.textContent = 'Usuário não encontrado.';
                errorEl.classList.remove('hidden');
              }
              input.setAttribute('data-state', 'error');
            } finally {
              if (loaderContainer) loaderContainer.classList.add('hidden');
            }
          },
          delay: 500,
        });
      }

      if (selectBtn) {
        selectBtn.addEventListener('click', () => {
          if (resultContainer) resultContainer.classList.add('hidden');
          const searchIcon = element.querySelector('[data-lucide="search"]');
          if (avatarEl && avatarEl.src && inputAvatar) {
            inputAvatar.src = avatarEl.src;
            inputAvatar.classList.remove('hidden');
            if (searchIcon) searchIcon.classList.add('hidden');
            input.classList.add('pl-8');
          }
          const value = (input.value || '').trim();
          if (value) element.setAttribute('data-value', value);
          if (errorEl) {
            errorEl.textContent = '';
            errorEl.classList.add('hidden');
          }
          input.removeAttribute('data-state');
        });
      }
    });

    ensureLucide();
  }

  function collect(container, validate) {
    if (!container) {
      container = document.querySelector('[data-custom-fields-fields]');
      if (validate === undefined) validate = true;
    }
    const result = {};
    if (!container) return result;
    let valid = true;
    container.querySelectorAll('[data-field-id]').forEach((element) => {
      const fieldId = element.getAttribute('data-field-id');
      const fieldType = element.getAttribute('data-field-type');
      if (!fieldId) return;

      let value = '';
      if (fieldType === 'SELECT') {
        const select = element.querySelector('select');
        value = (select && select.value) || '';
      } else if (fieldType === 'ROBLOX') {
        value = element.getAttribute('data-value') || '';
      } else {
        const input = element.querySelector('input');
        value = (input?.value || '').trim();
      }
      if (value) result[fieldId] = value;

      if (validate) {
        const control = element.querySelector('input, select');
        const required = control && control.getAttribute('data-required') === 'true';
        if (required && !value) {
          valid = false;
          if (control) control.setAttribute('data-state', 'error');
          const err = document.getElementById(`error-${fieldId}`);
          if (err) {
            err.textContent = 'Campo obrigatório.';
            err.classList.remove('hidden');
          }
        }
      }
    });
    return validate && !valid ? null : result;
  }

  function addToCart(options) {
    const { id, quantity = 1, fields = [], opts = {}, onAdded } = options || {};

    const done = (collected) => {
      if (window.Cart) window.Cart.add(id, quantity, collected || {}, opts);
      if (typeof onAdded === 'function') onAdded(collected || {});
    };

    if (!Array.isArray(fields) || !fields.length) return done({});

    const container = document.getElementById('product-fields-fields');
    const confirmBtn = document.getElementById('product-fields-confirm');
    if (!container || !confirmBtn || typeof window.renderProductFields !== 'function') {
      return done({});
    }

    container.innerHTML = window.renderProductFields(fields);
    afterRender(container);

    const fresh = confirmBtn.cloneNode(true);
    confirmBtn.parentNode.replaceChild(fresh, confirmBtn);
    fresh.addEventListener('click', () => {
      const collected = collect(container, true);
      if (collected === null) return;
      if (typeof closeDialog === 'function') closeDialog('product-fields');
      done(collected);
    });

    if (typeof openDialog === 'function') openDialog('product-fields');
    try {
      window.lucide?.createIcons?.();
    } catch {}
  }

  function hasAny() {
    const container = document.querySelector('[data-custom-fields-fields]');
    if (!container) return false;
    return container.querySelector('[data-field-id]') !== null;
  }

  window.CustomFields = Object.assign(window.CustomFields || {}, {
    afterRender,
    collect,
    hasAny,
    addToCart,
  });
})();
