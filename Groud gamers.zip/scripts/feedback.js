(function () {
  const card = document.getElementById('feedback-card');
  if (!card) return;

  const orderId = card.dataset.orderId;
  const mode = card.dataset.mode === 'edit' ? 'edit' : 'create';
  const sent = document.getElementById('feedback-sent');
  const editToggle = document.getElementById('feedback-edit-toggle');
  const editCancel = document.getElementById('feedback-edit-cancel');
  const stars = Array.from(document.querySelectorAll('#feedback-stars .feedback-star'));
  const suggestions = Array.from(document.querySelectorAll('.feedback-suggestion'));
  const messageEl = document.getElementById('feedback-message');

  const savedRating = Number(card.dataset.rating) || 0;
  const savedMessage = messageEl.value.trim();

  let rating = savedRating;

  function paint(value) {
    stars.forEach((star) => {
      const filled = Number(star.dataset.value) <= value;
      const svg = star.querySelector('svg');

      star.classList.toggle('text-yellow-400', filled);
      star.classList.toggle('text-muted-foreground', !filled);

      if (svg) {
        svg.classList.toggle('fill-yellow-400', filled);
        svg.classList.toggle('fill-transparent', !filled);
      }
    });
  }

  function paintSuggestion(chip, active) {
    chip.classList.toggle('feedback-suggestion-active', active);
    chip.classList.toggle('bg-primary', active);
    chip.classList.toggle('hover:bg-primary/80', active);
    chip.classList.toggle('text-background', active);
  }

  function syncSuggestions() {
    const parts = messageEl.value.trim().split(/\s*\.\s*/).filter(Boolean);

    suggestions.forEach((chip) => {
      paintSuggestion(chip, parts.includes(chip.dataset.suggestion || ''));
    });
  }

  stars.forEach((star) => {
    const value = Number(star.dataset.value);

    star.addEventListener('mouseenter', () => paint(value));
    star.addEventListener('mouseleave', () => paint(rating));
    star.addEventListener('click', () => {
      rating = value;
      paint(rating);
    });
  });

  suggestions.forEach((chip) => {
    chip.addEventListener('click', () => {
      const phrase = chip.dataset.suggestion || '';
      const active = !chip.classList.contains('feedback-suggestion-active');

      paintSuggestion(chip, active);

      const current = messageEl.value.trim();
      const parts = current ? current.split(/\s*\.\s*/).filter(Boolean) : [];

      if (active) {
        if (!parts.includes(phrase)) parts.push(phrase);
      } else {
        const index = parts.indexOf(phrase);
        if (index !== -1) parts.splice(index, 1);
      }

      messageEl.value = parts.length ? parts.join('. ') + '.' : '';
    });
  });

  function openEditor() {
    if (sent) sent.classList.add('hidden');
    card.classList.remove('hidden');
    card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function closeEditor() {
    rating = savedRating;
    messageEl.value = savedMessage;
    paint(rating);
    syncSuggestions();

    card.classList.add('hidden');
    if (sent) sent.classList.remove('hidden');
  }

  if (editToggle) editToggle.addEventListener('click', openEditor);
  if (editCancel) editCancel.addEventListener('click', closeEditor);

  paint(rating);
  syncSuggestions();

  window.submitFeedback = async function () {
    if (rating < 1) {
      toast.error('Selecione uma nota de 1 a 5 estrelas.');
      return;
    }

    const message = messageEl.value.trim();

    if (mode === 'edit' && rating === savedRating && message === savedMessage) {
      closeEditor();
      return;
    }

    const submitBtn = document.getElementById('feedback-submit');
    const originalText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.textContent = mode === 'edit' ? 'Salvando...' : 'Enviando...';

    try {
      if (mode === 'edit') {
        const t = new URLSearchParams(location.search).get('t');

        await CentralCart.fetch(
          `/rest/order/${orderId}/feedback${t ? `?t=${encodeURIComponent(t)}` : ''}`,
          { rating, message: message || undefined },
          'PATCH'
        );

        toast.success('Avaliação atualizada.');
      } else {
        await CentralCart.submitFeedback(orderId, { rating, message });

        toast.success('Avaliação enviada. Obrigado pelo seu feedback!');
      }

      window.location.reload();
    } catch (error) {
      toast.error(error.data?.errors?.[0]?.message || error.data?.message || 'Erro ao enviar avaliação.');
      submitBtn.disabled = false;
      submitBtn.textContent = originalText;
    }
  };
})();

(function () {
  function initFeedbackSlider() {
    const slider = document.getElementById('feedback-slider-1');
    if (!slider || slider.dataset.initialized) return;
    if (typeof KeenSlider === 'undefined') return setTimeout(initFeedbackSlider, 50);

    const originalCount = slider.children.length;
    if (originalCount === 0) return;

    const min_slides = 8;
    if (originalCount < min_slides) {
      slider.innerHTML = slider.innerHTML.repeat(Math.ceil(min_slides / originalCount));
    }

    slider.dataset.initialized = '1';

    if (window.lucide) window.lucide.createIcons();

    function continuousAutoplay(instance) {
      const animation = { duration: 10000, easing: (t) => t };
      let paused = false;

      function startAnimation() {
        if (paused) return;
        instance.moveToIdx(instance.track.details.abs + 2, true, animation);
      }

      instance.on('created', () => {
        instance.container.addEventListener('mouseenter', () => {
          paused = true;
          instance.animator.stop();
        });
        instance.container.addEventListener('mouseleave', () => {
          paused = false;
          startAnimation();
        });
        startAnimation();
      });
      instance.on('updated', startAnimation);
      instance.on('animationEnded', () => {
        if (!paused) setTimeout(startAnimation, 0);
      });
      instance.on('dragEnded', startAnimation);
    }

    new KeenSlider(
      slider,
      {
        loop: true,
        renderMode: 'performance',
        slides: { perView: 3, spacing: 16 },
        breakpoints: {
          '(max-width: 1024px)': { slides: { perView: 2, spacing: 12 } },
          '(max-width: 768px)': { slides: { perView: 1, spacing: 8 } },
        },
      },
      [continuousAutoplay]
    );
  }

  if (document.readyState === 'complete') initFeedbackSlider();
  else window.addEventListener('load', initFeedbackSlider);
})();

(function () {
  const list = document.getElementById('package-feedbacks-list');
  if (!list) return;

  const select = document.getElementById('package-feedbacks-filter');
  const empty = document.getElementById('package-feedbacks-empty');
  const sentinel = document.getElementById('package-feedbacks-sentinel');
  const items = Array.from(list.querySelectorAll('[data-rating]'));
  const BATCH = 10;

  let filter = 'all';
  let shown = BATCH;

  function getFiltered() {
    return filter === 'all' ? items : items.filter((item) => item.dataset.rating === filter);
  }

  function apply() {
    const filtered = getFiltered();
    const set = new Set(filtered);
    let index = 0;

    items.forEach((item) => {
      if (!set.has(item)) {
        item.style.display = 'none';
        return;
      }
      item.style.display = index < shown ? '' : 'none';
      index++;
    });

    if (empty) empty.classList.toggle('hidden', filtered.length > 0);

    const hasMore = shown < filtered.length;
    if (sentinel) sentinel.style.display = hasMore ? '' : 'none';
    return hasMore;
  }

  const observer = sentinel
    ? new IntersectionObserver(
        (entries) => {
          if (!entries.some((entry) => entry.isIntersecting)) return;

          const filtered = getFiltered();
          if (shown >= filtered.length) {
            observer.unobserve(sentinel);
            return;
          }

          shown = Math.min(shown + BATCH, filtered.length);
          const hasMore = apply();

          observer.unobserve(sentinel);
          if (hasMore) observer.observe(sentinel);
        },
        { root: list, rootMargin: '0px 0px 120px 0px', threshold: 0 }
      )
    : null;

  function reset() {
    shown = BATCH;
    const hasMore = apply();
    list.scrollTop = 0;

    if (observer) {
      observer.unobserve(sentinel);
      if (hasMore) observer.observe(sentinel);
    }
  }

  if (select) {
    select.addEventListener('change', () => {
      filter = select.value;
      reset();
    });
  }

  reset();
})();
